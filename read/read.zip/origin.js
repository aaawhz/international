﻿ThinkMail.namespace("module.payPhoneManager", function (TMK) {
    var C = TMK.control, T = TMK.tool, Util = TMK.util, MB = TMK.module.IModule, Lang = TMK.$LANG("corp");
    var gMain = TMK.global,
        formx = Util.Formx;

    var payPhoneManager = {
        isloading: false,
        init: function () {

        },//初始化    
        render: {
            pageSize: 20,
            pageIndex: 0,
            langConf: "",
            checkboxVal:[],
            taskNameVal:{
                "1":"加班审批",
                "2":"请假审批",
                "3":"通用审批",
                "4":"项目审批"
            },
            initpayPhoneManager: function () {
                ThinkMail.comm.initLeftMeu("payPhoneManager");
            },
            initOaList: function (langConf) {
                payPhoneManager.actions.bind();
                payPhoneManager.render.langConf = langConf;
                ThinkMail.comm.initLeftMeu("payPhoneManager");  //初始化左侧菜单，被选按钮高亮
                payPhoneManager.actions.initStartDate();  //初始化查询的时间
               
                payPhoneManager.actions.initDefautText(); 
                payPhoneManager.actions.initDrop();        //初始化两个下拉框-类别和结果
           
                $("#searchReport").click(function () {  //点击“搜索”按钮
                    payPhoneManager.render.pageIndex = 0;

                    　payPhoneManager.actions.list.pageIndex = 0; 
                                  
                    //key, taskState, taskName, beginDate, endDate, isGoPage
                    var key = $("#txt_corpPayNumber").val();
                    var taskState = payPhoneManager.taskStateDrop.getValue();
                    var corpName = $("#txt_corpName").val();
                    
                    var beginDate = $("#txtStart").val();
                    var endDate = $("#txtEnd").val();

                    if(payPhoneManager.actions.check()){
                        payPhoneManager.actions.loadOaList(key,taskState,corpName,beginDate,endDate);
                    }    
                })


                ThinkMail.comm.setTxtDefault($(".search_txt"));   //设置输入框默认值 这里是搜索框

                 
                var beginDate = $("#startDate").val();
                var endDate = $("#endDate").val();

                payPhoneManager.actions.loadOaList(null, payPhoneManager.taskStateDrop.getValue(),null,beginDate,endDate,null);   //显示列表,默认查询七天内的数据

            },
             /**
             * 冲时长
             * @param user
             */
            payCharge: function (user, o) {
                var p = this;

                p.itemData = o;

                if (!user) return;

               
                var temp = '';

                

                 temp = '<ul class="st_formLine" style="padding-top:20px;">'+
                          
                            '<li class="clearfix" msg="" verify="match" reg="zip">'+
                                '<label class="st_name" style="width:110px;"> 冲时长：</label>'+

                                '<div class="st_formLine_rt" data-role="control">'+
                               '     <input class="com_txt col_black" style="width:165px"   name="" maxlength="20" id="txtCharge" type="text"> &nbsp; 分钟'+
                               ' </div>'+
                          '  </li>'+
                            '<li class="clearfix " verify="match" reg="phone">'+
                             '   <label class="st_name"  style="width:110px;"> 有效期至：</label>'+

                              '  <div class="st_formLine_rt" data-role="control">'+
                                 '   <input class="com_txt col_black" style="width:165px"  id="txtDate" readOnly="readOnly" name="contactMobile" type="text">'+
                             '   </div>'+
                           ' </li>'+

                            '<li class="clearfix" verify="match" max="200">'+
                              '  <label class="st_name"  style="width:110px;">验证码</label>'+

                              '  <div class="st_formLine_rt" style="width: ">'+
                                '    <input class="com_txt col_black" style="width:165px"   id="txtCode" type="text" maxlength="20">'+

                                   ' <a href="javascript:;" id="getCorpZip" class="btnTb ml_10">'+
                                   ' <span>获取验证码</span></a>'+
                                    '<span id="getZipCodeWait" style="display: none"> '+
                                    '    <span id=""> <span id="secs" style="color: green; font-weight: bold;">60</span>秒后再获取验证码 </span>'+
                                   ' </span> '+
                                                            
                               ' </div>'+

                            '</li>'+
                             
                        '</ul>' ;
         

               // var userList_html = Util.format(temp, user);
                clearInterval(payPhoneManager.timer);

                ThinkMail.CC.showDiv(temp, null, '冲时长', null, "ShowUserInfo", 425, [
                    {
                        text: "提交",
                        clickEvent: function () {
                            var num = $("#txtCharge", top.document).val();
                            var txtCode = $("#txtCode", top.document).val();

                            p.chargeNum = num;
                            p.txtCode = txtCode;
                            
                            if(!num){
                                ThinkMail.CC.showMsg("请输入时长", 'error');
                                return true;
                            }

                            if( !p.selectDate ){
                                ThinkMail.CC.showMsg("请选择有效期", 'error');
                                return true;
                            }

                            if(!txtCode){
                                ThinkMail.CC.showMsg("请输入验证码", 'error');
                                return true;
                            }

                            clearInterval(payPhoneManager.timer);

                            payPhoneManager.request.payCharge(p.itemData, p.selectDate, p.txtCode, p.chargeNum);
                        }
                    } 
                ]);

                p.initChargeTxt();
                p.initStartDate();
                p.initZipCodehe();
            },
            initZipCodehe: function(){
                var p = this;
                

                $("#getCorpZip", top.document).on('click', function(){
                    var num = $("#txtCharge", top.document).val();
                    var txtCode = $("#txtCode", top.document).val();

                    p.chargeNum = num;
                    p.txtCode = txtCode;

                    if(!num){
                        ThinkMail.CC.showMsg("请输入时长", 'error');
                        return true;
                    }

                    if( !p.selectDate ){
                        ThinkMail.CC.showMsg("请选择有效期", 'error');
                        return true;
                    }
                    payPhoneManager.request.getCorpZip(p.itemData, p.selectDate, p.txtCode, p.chargeNum);
                });
            },
            initChargeTxt: function(){
                //只能输入数字
                $("#txtCharge", top.document).on("keyup afterpaste", function(e){
                    this.value = this.value.replace(/\D/g, '' );
                });
            },
            initStartDate: function(){
                var p = this;
                var td = new Date();
                    td = td.getFullYear() + "-" + (td.getMonth()+1) +"-" + (td.getDate()+1);
                    
                    if($(".ui-date")[0], top.document){
                        $(".ui-date", top.document).remove();
                    }
                 
                    p.startCalendar = new ThinkMail.control.Calendar("#txtDate", {
                        showTop:true,
                        onSelect: function(oDate){
                            var yyyy = parseInt(oDate["yyyy"], 10);
                            var mm = parseInt(oDate["mm"], 10);
                            var dd = parseInt(oDate["dd"], 10);
                            
                            p.selectSeconds = new Date(yyyy, mm - 1, dd).getTime() / 1000;          
                            p.sDate = yyyy + "-" + mm + "-" + dd;
                            p.sDate = payPhoneManager.actions.toDoubleDate(p.sDate);
                            p.startSeconds = p.selectSeconds;  //用来对比结束时间 和 开始时间
                            //p.selectDate = yyyy + "年" + mm + "月" + dd + "日";
                            p.selectDate = p.sDate;


                            //返还true 表示执行其他点击事件，比如改变输入框的文本值
                            return true;
                        },
                        txtDate:  p.sDate,
                        maxDate: td,
                        onSelectBack: function(oDate){
                            cbStart();
                            return true;
                            
                        }
                    });
               
                
                var cbStart = function(){
                    $("#txtDate").val(p.selectDate);
                };
            }

        },
        actions: {
            name:"config",

            bind: function(){
                var p = this;
                var $elementWrap = $("#oaFilling-wrap");
                $elementWrap.on('click', '[data-action]', function(e) {
                    var action = $(this).data('action');
                    if(action=="migrate-step"){
                        Util.Ajax.admin("?func=config:moveMailConfig", {}, function (json) {
                            p.go(json.exist == 1 ? "migrate-list" : "migrate");
                        }, function () {
                            p.go('migrate')
                        });                        
                    }
                    if(action=="migrateAll-step"){
                        Util.Ajax.admin("?func=config:moveMailConfig", {}, function (json) {
                            p.go(json.exist == 1 ? "import-list" : "migrateAll");
                        }, function () {
                            p.go('migrateAll')
                        });                        
                    }

                });
            },

            go: function(func, params){
                params = $.extend({}, this._params(), params);
                if (!func) {
                    return history.go(-1);
                }
                location.href = Util.format("admintransit.do?sid={sid}{params}&func={MODULE_NAME}:{func}", {MODULE_NAME: params.MODULE_NAME || this.name, sid: TMK.global.sid, func: func || "", params: params ? Util.getParamsStr(params) : ""});
            },

            _params: function () {
                var t = this;
                return {
                    /*seqNo: t.seqNo*/
                };
            },

            loadOaList: function (key, taskState, corpName, beginDate, endDate, isGoPage) {
            
              
                var p = this;
                var isSearch = false;

                reqData = {
                    
                    "corpName": "",
                    "chargeState": 3,
                    "beginTime": "",
                    "endTime": ""
                };
 
                if(corpName){
                    reqData.corpName= corpName;                                                   
                }
 
                if( beginDate ){
                    reqData.beginTime = beginDate + ":00";
                }

                

                if( endDate ){
                    reqData.endTime = endDate + ":00";
                }

                if( typeof taskState != 'undefined' && taskState !== '' ){
                    reqData.chargeState =  parseInt(taskState,10);
                    isSearch = true;
                }else{

                }
 
                var page = {pageSize: payPhoneManager.render.pageSize, pageNo: (payPhoneManager.render.pageIndex || 0) * payPhoneManager.render.pageSize};
               
               
                if (  taskState || reqData.corpName  || reqData.begin || reqData.end) {
                    isSearch = true;
                }

                if( isGoPage ){
                    isSearch = false;
                    reqData = payPhoneManager.cacheSearchData;

                } 
 
                if (isSearch && payPhoneManager.render.pageIndex == 0) {
                    p.list = null;
                }

                payPhoneManager.cacheSearchData = reqData;


                payPhoneManager.request.list(reqData, page, function (data) {
                    var dataList = data.applys;
                    if (!p.list) {
                        p.list = new ThinkMail.list({
 
  
                            "columns": [
                                {
                                    "columnId": "applyTime",
                                    "columnName": '提交时间',
                                    "columnClassName": "",
                                    "titleStyle":"width:15%",
                                    "callback": function (value, id, rows) {
                                        var result = '';

                                        try{
                                            result = new Date(rows.applyTime.time).format();
                                           
                                        }
                                        catch(e){

                                        }

                                        return result;
                                    }
                                },
                                {
                                    "columnId": "corpName",
                                    "columnName": '企业',
                                    "showTitle": true,
                                     "titleStyle":"width:15%"
                                },
                                {
                                    "columnId": "applyPerson",
                                    "columnName": '管理员邮箱账号',
                                     "titleStyle":"width:18%"
                                },
                                {
                                    "columnId": "packageType",
                                    "columnName": '套餐',
                                     "titleStyle":"width:10%" 
                                },
                                {
                                    "columnId": "packageNum",
                                    "columnName":'金额',
                                     "titleStyle":"width:10%"
                                },
                                {
                                    "columnId": "packageTime",
                                    "columnName": '时长',
                                     "titleStyle":"width:10%"
                                } ,
                                {
                                    "columnId": "chargeState",
                                    "columnName": '状态',
                                    "titleStyle":"width:10%",
                                    "callback": function(key,o){
                                        // chargeState  充值状态 0 未充值  2已充值 1 充值失败
                                        var result = '';

                                        switch(key){
                                            case 0:
                                                result = '未充值';
                                                break;
                                            case 2:
                                                result = '已充值';
                                                break;
                                            case 1:
                                                result = '充值失败';
                                                break;        
                                        }

                                        return result;
                                    }
                                } 
                                  
                                                                                             
                            ],
                             "operateList": [
                                {
                                    "text": '冲时长',
                                    "changeText": function (rows) {
                                        return '冲时长';
                                    },
                                    "callback": function (id,o) {
                                      payPhoneManager.render.payCharge(id,o);
                                    }
                                }
                             ],   
                            "key": "corpId",
                            "info_templates": ThinkMail.$LANG("corp.corp.info_templates").format(payPhoneManager.render.langConf, data.count, data.suspendCount, data.cancelCount),
                            "bingContorlId": "listContent",
                            "onCheckbox": function (result) {
                                //多选框的点击事件
                                //result就是选中的项的data-key的值，而data-key绑定的属性则是由上面的"key"决定
                                //这里绑定的是"key":"businessId"
                                result=result.split(",");
                                payPhoneManager.render.checkboxVal=[];
                                for (var i = 0; i < result.length; i++) {
                                    payPhoneManager.render.checkboxVal[i]=result[i];
                                };

                            },
                            "isCheckButton": true,
                            "checkButtonCallback": function (rows) {
                                return true;
                            }
                        });
                    }
                    if (isSearch) {
                        p.list.info_templates = ThinkMail.$LANG("corp.corp.search_label").format(data.totalCount);
                    }
                    else {
                        p.list.info_templates = '<span class="col_grey">所有<var>{0}</var>条</span> '.format(data.totalCount);
                    }
                    p.list.setInfo()  //设置信息栏 将p.list.info_templates的值显示出来，如企业XX个,暂停XX个,注销XX个
                    p.list.page = {
                        "count": data.totalCount,
                        "pageSize": payPhoneManager.render.pageSize,
                        "goPageCallback": payPhoneManager.actions.goPage   //点击上下一页的回调函数
                    };
                    p.list.dataBind(data.applys);  //绑定数据，将列表信息显示出来
                     
                    $(".table-info").click(function (event) { //信息栏的【a链接】点击事件
                        var target = event.target;
                        if (target.nodeName == "A") {
                            payPhoneManager.render.pageIndex = 0;
                            payPhoneManager.actions.loadOaList(null, target.getAttribute("value"));
                        }
                    })
                })
            }, //key, taskState, taskName, beginDate, endDate, isGoPage
            goPage: function (pageIndex) {
              
                payPhoneManager.render.pageIndex = pageIndex;
                payPhoneManager.actions.loadOaList(null, null, null, null, null,"goPage");
            },
            decodeInfo: function(obj) {    
                String.prototype.decodeHTML=top.String.prototype.decodeHTML
                function decodeHTML(obj){
                    jQuery.each(obj,function(i){
                        switch (jQuery.type(obj[i])){
                            case 'string':
                                obj[i]=obj[i].decodeHTML()
                                break;
                            case 'object':
                                decodeHTML(obj[i])
                                break;
                            case 'array':
                                decodeHTML(obj[i])
                                break;
                        }
                    })
                    return obj;
                }
                return decodeHTML(obj);             
            },            
             

            // bind: function () {
            //     return formx.create({form: "#uform"});
            // },

            initStartDate: function(){
 
                var p = this;
                var td = new Date();
                td = td.getFullYear() + "-" + (td.getMonth()+1) +"-" + (td.getDate()+1);
                
                require(["control/avalonUI/datepicker/avalon.datepicker", "control/avalonUI/slider/avalon.slider"], function(avalon) {
                    p.endCalendar = avalon.define("dateStart", function(vm) {
                       vm.sDate = ''; //ThinkMail.comm.getFormatDate( new Date() , '-' );
                       p.sDate  = '';

                        vm.datepicker = {
                            onSelectTime: function(vmodel) {
                                var currentTime = new Date(vmodel.year, vmodel.month, vmodel.day, vmodel.hour, vmodel.minute)
                               // avalon.log("currentTime is : "+currentTime)
                             
                               p.sDate = ThinkMail.comm.getFormatDate(new Date(currentTime) , '-');
                               vm.sDate = p.sDate;
                               
                               $("#txtStart").val(p.sDate);
                            }
                        }
                        
                  
                        
                        //blog.sDate = vm.sDate;
        
                        
                    });

                    p.endCalendar = avalon.define("dateEnd", function(vm) {
                        vm.eDate = ''; // ThinkMail.comm.getFormatDate( new Date() , '-'  );
                        p.eDate = '';

                        vm.datepicker = {
                            onSelectTime: function(vmodel) {
                                var currentTime = new Date(vmodel.year, vmodel.month, vmodel.day, vmodel.hour, vmodel.minute)
                               // avalon.log("currentTime is : "+currentTime)
                               

                             p.eDate = ThinkMail.comm.getFormatDate(new Date(currentTime) , '-');
                             vm.eDate = p.eDate;
                             $("#txtEnd").val(p.eDate);
                  
                            }
                        }
                
                    })

                    avalon.scan();
                })
                
         
            },

     
            /**
             * 2010-1-8 --> 2010-10-08
             * @param {Object} date
             */
            toDoubleDate: function(date){
                var p = this;
                
                date = date.split(/[-]/);
                
                for(var i = 0,len=date.length; i<len; i++){
                    date[i] = p.toDouble(date[i]);
                }
                
                return date.join("-");
            },

            /**
             * 1 --> 01
             * @param {Object} val
             */
            toDouble: function(val){
                return (val+"").length<2 ? 0+(val+"") : (val+"");
            },

            /**
             * 设置开始的时间
             * @param {Object} date
             */
            setStartDate: function(date){
                var p = this;
                var d = new Date();     
                d.setDate(d.getDate()-date);
                
                var yyyy = d.getFullYear(),
                    mm   = d.getMonth(),
                    dd   = d.getDate();
                p.sDate = yyyy + "-" + (mm+1) + "-" + dd;
                p.sDate = p.toDoubleDate(p.sDate);
                    
                //$("#startDate").val(yyyy + "年" + (mm+1) + "月" + dd + "日");
                $("#startDate").val(p.sDate);
            },

            /**
             * 设置结束时间
             * @param {Object} date
             */
            setEndDate: function(date){
                var d = new Date(),
                    p = this,
                    yyyy = d.getFullYear(),
                    mm   = d.getMonth(),
                    dd   = d.getDate();
                
                if(date == "today"){
                    p.eDate = yyyy + "-" + (mm+1) + "-" + dd;
                    p.eDate = p.toDoubleDate(p.eDate);
                    //$("#endDate").val(yyyy + "年" + (mm+1) + "月" + dd + "日");
                    $("#endDate").val(p.eDate);
                }
            },  
            initDrop : function(){
                var p = this;
                
                if($("#taskType_drop")[0]){
                    if(!p.taskTypeDrop){
                        
                        p.initTypeFilterDrop();
                    }
                }
                
                if($("#meetState_drop")[0]){
                    if(!p.taskStateDrop){
                        p.initStateFilterDrop();
                    }
                }
        
            },

            initTypeFilterDrop: function(){
            
                var p = this,
                    drop =  "",
                    h = 80,
                    data = [],
                    obj = "";
                
                //全部, 加班, 请假，通用，项目
                data = data.concat([{"text":ThinkMail.$LANG("config.oa.all_category") ,"value":0},{"text":"加班审批" ,"value":1},{"text": "请假审批" ,"value":2},
                {"text":"通用审批" ,"value":3},{"text":"项目审批" ,"value":4}]);                

                obj = {
                    id:"taskType_drop",
                    height:h,
                    width:145,
                    selectedValue:"0",
                    data:data,
                    itemClick: function(){
                        //需要重新刷新日志列表
                        // p.initPostData();
                    },
                    selectedValue: "0"   
                };
                $("#taskType_drop").html("");
                
                //payPhoneManager.taskTypeDrop = new ThinkMail.DropSelect(obj);
                
            },

            initStateFilterDrop: function(){
            
                var p = this,
                    drop =  "",
                    h = 103,
                    data = [],
                    obj = "";
                
                //全部 3通过 4驳回
                data = data.concat([{"text":ThinkMail.$LANG("config.oa.all") ,"value":3},
                    {"text":'未充值',"value":0},
                    {"text":'已充值',"value":2},
                    {"text":'充值失败',"value":1} 
                ]);

                obj = {
                    id:"meetState_drop",
                    height:h,
                    width:145,
                    selectedValue:"0",
                    data:data,
                    itemClick: function(){
                        //需要重新刷新日志列表
                        // p.initPostData();
                    },
                    selectedValue: "0"   
                };
                $("#meetState_drop").html("");
                
                payPhoneManager.taskStateDrop = new ThinkMail.DropSelect(obj);
                
            },

            initDefautText: function(){
                var p = this,
                    t = ThinkMail;
                
               /* p.accountText = t.$LANG("config.oa.search_label"); // 按发起人或审批人查询
                p.accountObj = $("#txt_subject");
                
                t.comm.setTxtDefault(p.accountObj,p.accountText);   */
                
            },

             check: function(){
                var p = this,
                    t = ThinkMail;
 
                //p.startSeconds > p.endSeconds
                if(p.sDate.toDate() > p.eDate.toDate()){
                    t.CC.showMsg(ThinkMail.$LANG('report.reportTip2'),"fail");  //  // 结束时间不能大于开始时间
                    return false;
                }
                return true;
            },

            checkVal: function(){
                var p =this;
                if(p.dealArray(payPhoneManager.render.checkboxVal).length==0){
                    ThinkMail.CC.showMsg(ThinkMail.$LANG("config.oa.export_tips_null"),"fail");
                    return false;
                }
                return true;
            },            

            dealArray: function(arr){
                for (var i = 0; i < arr.length; i++) {
                    if(arr[i]==""||typeof(arr[i]) == "undefined"){
                        arr.splice(i,1);
                    }
                };
                return arr;
            }

        },
        request: {
            getCorpZip: function(itemData, selectDate, txtCode, chargeNum){
                var succall = function(){

                    ThinkMail.CC.showMsg("验证码已发送, 请查收");

                    $("#getCorpZip", top.document).hide();
                    $("#getZipCodeWait", top.document).show();

                    $("#getCorpZip", top.document).focus();

                    var time = 60;
                    var timer = setInterval( function(){
                        if( --time ){
                            $("#secs", top.document).text( time );
                        }else{
                            clearInterval(timer);
                            timer = null;

                            $("#getCorpZip", top.document).show();
                            $("#getZipCodeWait", top.document).hide();

                        }

                    }, 1000);

                    payPhoneManager.timer = timer;

                };

                var data = {
                            "applyId": itemData.applyId,
                            "corpId": itemData.corpId,
                            "balance": chargeNum,
                            "expirydate": selectDate.replace(/\-/g,'')
                           };

                ThinkMail.util.Ajax.admin("?func=muti:getCodeForCharge", {
                    data: data
                }, succall, function () {
                    succall();
                    ThinkMail.CC.showMsg('获取验证码失败', 'fail');
                });
            },
            getInfo: function (data, callback) {
                ThinkMail.util.Ajax.admin("?func=workflow:getWorkFlow", {
                    data: data
                }, callback, function (daa) {
                    ThinkMail.CC.showMsg(ThinkMail.$LANG("comm.load_fail"), "fail");
                });
            },
            payCharge: function(itemData, selectDate, txtCode, chargeNum){
                var data = {
                    "applyId":itemData.applyId,
                    "corpId": itemData.corpId,
                    "balance": chargeNum,
                    "expirydate": selectDate.replace(/\-/g,''),
                    "validateCode": txtCode
                };

                ThinkMail.util.Ajax.admin("?func=muti:dealChargeApply", {
                    data: data
                }, callback, function (daa) {
                    ThinkMail.CC.showMsg(ThinkMail.$LANG("comm.load_fail"),"fail");
                });
            },
            list: function (data, page, callback) {
                ThinkMail.util.Ajax.admin("?func=muti:getCorpChargeApply&pageSize=" + page.pageSize + "&pageNo=" + page.pageNo, {
                    data: data
                }, callback, function (data) {
                    if (data != "error") {
                        ThinkMail.CC.showMsg(ThinkMail.$LANG("corp.corp.load_list_fail").format(payPhoneManager.render.langConf), "fail");
                    }
                });
            }
        }
    }
    window["payPhoneManager"] = payPhoneManager;
    return payPhoneManager;
});
 
            
       
